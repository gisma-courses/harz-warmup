# Analyse des ursprünglichen QMD-Skriptteils

Quelle: `mc_2025_microclimate_viewer_merged.qmd` aus dem EON2025-Repository.

## Was das Originalskript macht

Das QMD bildet eine vollständige Mikroklima-Pipeline ab:

1. Pakete laden und Hilfsfunktionen definieren.
2. Projektpfade setzen und ein großes Funktionsskript einbinden.
3. DEM, Stationspunkte und Untersuchungsgebiet laden.
4. Ecowitt-Loggerdaten einlesen, Spaltennamen bereinigen und auf 3-Stunden-Werte aggregieren.
5. Stationsdaten mit Temperatur-Zeitspalten und DEM-Höhe verbinden.
6. Pro Zeitpunkt eine KED-Interpolation erzeugen.
7. Einen dichten Zeitpunkt auswählen.
8. DEM-Prädiktoren wie Hangneigung, Exposition und TRI erzeugen.
9. R* über räumliche Kreuzvalidierung bestimmen.
10. Interpolationsmethoden benchmarken.
11. CSVs, Karten und Diagnostiken exportieren.
12. Optional einen Shiny-Viewer starten.

## Warum das für Anfänger zu viel ist

Das Original enthält mehrere didaktisch verschiedene Ebenen gleichzeitig:

- Datenimport aus realen Loggerdateien,
- Namensbereinigung,
- Geodaten-CRS und DEM-Strategie,
- geostatistische Interpolation,
- Skalen-/Radiuslogik,
- Kreuzvalidierung,
- Methodenvergleich,
- Bericht/Viewer/Export.

Für eine zweistündige Sitzung ist das als Komplettskript zu dicht. Die Vereinfachung muss daher bei Datenmenge, optionalen Verfahren und Dateistruktur ansetzen, nicht beim zentralen Denkweg.

## Was in der Beginner-Version erhalten bleibt

Die Beginner-Version erhält die Kernlogik:

- Sensorpunkte messen Temperatur.
- Ein DEM liefert räumliche Zusatzinformation.
- Aus Punktmessungen wird eine Fläche interpoliert.
- Ein Radius R beschreibt, auf welcher räumlichen Skala Geländeinformation genutzt wird.
- R* wird über Fehlervergleich gewählt.
- Mehrere Methoden werden mit RMSE verglichen.
- Karten, Tabellen und Figuren werden exportiert.

## Was bewusst vereinfacht wurde

- Statt zwei Excel-Loggern gibt es eine kleine CSV-Tabelle.
- Statt realem DEM wird ein kleines synthetisches DEM im Skript erzeugt.
- Statt aller Zeitpunkte wird ein dichter Zeitpunkt verpflichtend gerechnet.
- Statt vollem KED wird eine KED-ähnliche Drift-Residual-Logik genutzt: Höhen-Drift plus räumlich interpolierter Restfehler.
- Statt Shiny-Viewer stehen PNG-Karten und GeoTIFFs im Vordergrund.
- Das Projekt läuft als entpackbarer `.Rproj`-Ordner ohne externe Datenbeschaffung.
